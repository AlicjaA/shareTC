﻿using System.IO;

namespace OTPLibrary.Logic
{
	public class NameGenerator
	{
		public FileNamesPack GenerateFileNames(string originalName)
		{
			FileNamesPack pack = new FileNamesPack();

			string nameWithoutExtension = originalName.Substring(0, originalName.Length - 4);
	
			pack.inputName = originalName;
			pack.keyName = nameWithoutExtension + "Key";
			pack.outputName = originalName;

			return pack;
		}

		public FileNamesPack GetOnlyKeyName()
		{
			FileNamesPack pack = new FileNamesPack();

			pack.inputName = "";
			pack.keyName = Directory.GetCurrentDirectory() + "TextKey";
			pack.outputName = "";

			return pack;
		}
	}

	public struct FileNamesPack
	{
		public string inputName;
		public string outputName;
		public string keyName;
	}
}
