﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Numerics;
using System.Text;

namespace OTPLibrary.Logic
{
    public class EncryptionLib
    {
        public string ProcessText(string inputText, string keyFile, ProcessType processType)
        {
            // Read input text
            byte[] inputBytes = Encoding.Unicode.GetBytes(inputText);
            List<byte[]> bitBlockTab = splittInputBytes(inputBytes, processType);

            // Generate or load the key
            BigNumber rabinKeyBytes;
            BigNumber pBytes = new BigNumber();
            BigNumber qBytes = new BigNumber();
           
            List<BigNumber> rabinOutputBytes=new List<BigNumber>();

            switch (processType)
            {

                case ProcessType.Encryption:
                    {
                        // Generate and save the key
                        rabinKeyBytes = new BigNumber(RabbinKeyGen(ref pBytes, ref qBytes));
                        byte[] checkBytes = new[] {rabinKeyBytes.getBytes()[0], rabinKeyBytes.getBytes()[1]};
                        for (int i=0;i < bitBlockTab.Count;++i)
                        {
                            var ms = new MemoryStream(new byte[bitBlockTab[i].Length+2], 0, bitBlockTab[i].Length + 2, true, true);
                            ms.Write(bitBlockTab[i], 0, bitBlockTab[i].Length);
                            ms.Write(checkBytes, 0, checkBytes.Length);
                            byte[] merged = ms.ToArray();
                            bitBlockTab[i] = merged;
                        }
                        
                        // Save key
                        List<BigNumber> listbByteses = new List<BigNumber>();
                        listbByteses.Add(pBytes);
                        listbByteses.Add(qBytes);
                        listbByteses.Add(rabinKeyBytes);
                        int c = 0;
                        foreach (var bytes in listbByteses)
                        {
                            string kfile = keyFile + c.ToString() + ".bin";
                            using (FileStream fs = new FileStream(kfile, FileMode.Create))
                            {
                                byte[] b = bytes.getBytes();
                                fs.Write(b, 0, b.Length);
                                fs.Dispose();
                            }
                            c++;
                        }


                        rabinOutputBytes = new List<BigNumber>();
                        rabinOutputBytes=RabinEncyption(bitBlockTab, rabinKeyBytes);
                        break;
                    }
                case ProcessType.Decryption:
                    {

                        List<BigNumber> listbByteses = new List<BigNumber>();

                        for (int i = 0; i < 3; ++i)
                        {
                            string kfile = keyFile + i.ToString()+".bin";
                            
                            using (FileStream fs = new FileStream(kfile, FileMode.Open))
                            {
                                byte[] keyBytes = new byte[fs.Length];
                                fs.Read(keyBytes, 0, keyBytes.Length);
                                fs.Dispose();
                                listbByteses.Add(new BigNumber(keyBytes.ToList()));
                                
                                
                            }

                            
                        }

                        pBytes= new BigNumber(listbByteses[0]);
                        qBytes = new BigNumber(listbByteses[1]);
                        rabinKeyBytes = new BigNumber(listbByteses[2]);
                        rabinOutputBytes=RabinDescription(bitBlockTab, rabinKeyBytes, pBytes, qBytes);
                        break;
                    }
            }
            
            return resultToString(rabinOutputBytes);
        }

        public string resultToString(List<BigNumber> result)
        {
            string outputString = "";
            foreach (BigNumber b in result)
            {
                byte[] bytes = b.getBytes() ;
                outputString += Encoding.Unicode.GetString(bytes);
            }

            return outputString;
        }

        public void ProcessFile(string inputFile, string keyFile, string outputFile, ProcessType processType)
        {
            // Open file and save its bytes
            BigNumber inputBytes;
            List<BigNumber> rabinOutputBytes = new List<BigNumber>();

            using (FileStream fs = new FileStream(inputFile, FileMode.Open))
            {
                byte[] tmp= new byte[fs.Length];
                fs.Read(tmp, 0, tmp.Length);
                inputBytes = new BigNumber(tmp.ToList());
            }
            BigNumber rabinKeyBytes = new BigNumber();
            BigNumber pBytes = new BigNumber();
            BigNumber qBytes = new BigNumber();

            // Generate or load the key
            switch (processType)
            {
                case ProcessType.Encryption:
                    {
                        // Generate and save the key
                        rabinKeyBytes=new BigNumber(RabbinKeyGen(ref pBytes, ref qBytes));

                        // Save key
                        List<BigNumber> listbByteses = new List<BigNumber>();
                        listbByteses.Add(pBytes);
                        listbByteses.Add(qBytes);
                        listbByteses.Add(rabinKeyBytes);
                        int c = 0;
                        foreach (var bytes in listbByteses)
                        {
                            using (var fs = File.OpenWrite(keyFile+c+".bin"))
                            {
                                using (var bw = new BinaryWriter(fs))
                                {

                                    bw.Write(bytes.getBytes()); // Write each byte array to the stream

                                }
                                fs.Dispose();
                            }

                            c++;
                        }

                        rabinOutputBytes = new List<BigNumber>();
                        //rabinOutputBytes.Add(RabinEncyption(inputBytes,rabinKeyBytes));
                        break;
                    }
                case ProcessType.Decryption:
                    {
                        List<BigNumber> listbByteses = new List<BigNumber>();

                        for (int i = 0; i < 3; ++i)
                        {
                            using (StreamReader file =
                                new StreamReader(File.OpenRead(keyFile + i+".bin")))
                            {
                                string line;
                                while ((line = file.ReadLine()) != null)
                                {
                                    listbByteses.Add(new BigNumber(Encoding.Unicode.GetBytes(line.ToCharArray())));
                                }

                                file.Dispose();
                            }
                        }

                        //rabinOutputBytes =RabinDescription(inputBytes, rabinKeyBytes, pBytes, qBytes);
                        break;
                    }
            }

          

            foreach (BigNumber b in rabinOutputBytes)
            {
                using (FileStream fs = new FileStream(outputFile, FileMode.Create))
                {
                    fs.Write(b.getBytes(), 0, b.getBytes().Length);
                    fs.Dispose();
                }

            }
            

            if (processType == ProcessType.Decryption)
            {
                for (int i = 0; i < 3; ++i)
                {
                    File.Delete(keyFile+i);
                }
            }
        }


        public List<byte[]> splittInputBytes(byte[] inBytes, ProcessType processType)
        {
            List<byte[]> bitBlockTab = new List<byte[]>();
            switch (processType)
            {
                case ProcessType.Encryption:
                {
                    int howManyBlocks = 1;
                    if ((inBytes.Length % 62) != 0)
                    {
                        howManyBlocks = (inBytes.Length / 62) + 1;
                    }
                    else { howManyBlocks = (inBytes.Length / 62); }
                    
                    int last = 0;
                    for (int i = 0; i < howManyBlocks; ++i)
                    {
                        byte[] tmp;
                        if (howManyBlocks == 1)
                        {
                            tmp = new byte[inBytes.Length];
                        }
                        else
                        {
                            int lengthCheck = inBytes.Length - last;
                            if (lengthCheck < 62)
                            {
                                tmp = new byte[lengthCheck];
                            }
                            else
                            {
                                tmp = new byte[62];
                            }
                        }


                        for (int j = 0; j < tmp.Length; ++j)
                        {
                            tmp[j] = inBytes[last + j];
                        }
                        bitBlockTab.Add(tmp);
                        last += 62;
                    }
                        break;
                }

                case ProcessType.Decryption:
                {
                    int howManyBloks = inBytes.Length / 16;
                    
                    byte[] tmp=null;
                    int last = 0;
                        for (int i = 0; i < howManyBloks; ++i)
                    {
                        
                        tmp = new byte[16];
                        for (int j = 0; j < tmp.Length; ++j)
                        {
                            tmp[j] = inBytes[last + j];
                            
                        }
                        bitBlockTab.Add(tmp);
                        last = last + 16;
                    }
                    break;
                }   
            }

            return bitBlockTab;
        }


        public BigNumber RabbinKeyGen(ref BigNumber pBytes, ref BigNumber qBytes)
        {
            Random r = new Random();
            pBytes = new BigNumber(pBytes.genPseudoPrime(64,1,r));
            qBytes=new BigNumber(qBytes.genPseudoPrime(64,1,r));
            if (!pBytes.isProbablePrime(1) || !qBytes.isProbablePrime(1))
            {
                RabbinKeyGen(ref pBytes, ref qBytes);
            }
            BigNumber n = pBytes* qBytes;
            return n;
        }

        public List<BigNumber> RabinDescription(List<byte[]> bitBlockTab, BigNumber publicKey, BigNumber pBytes, BigNumber qBytes)
        {
            List<BigNumber> blockSolutions= new List<BigNumber>();
            foreach (byte[] block in bitBlockTab)
            {
                List<BigNumber> list = new List<BigNumber>();
                BigNumber blockNumber= new BigNumber(block.ToList());
                BigNumber m1, m3, m2, m4, a, b;
                BigNumber[] ab = blockNumber.ext_gcd(pBytes, qBytes);
                m1 = new BigNumber(blockNumber.modPow((pBytes + BigNumber.ONE) / (BigNumber.FOUR), pBytes));
                m2 = new BigNumber(pBytes - m1);
                m3 = new BigNumber(blockNumber.modPow((qBytes + BigNumber.ONE) / (BigNumber.FOUR), qBytes));
                m4 = new BigNumber(qBytes - m3);
                a = new BigNumber(ab[0]);
                b = new BigNumber(ab[1]);
                list.Add(new BigNumber(((a * pBytes * m3) + (b * qBytes * m1)) % (publicKey)));
                list.Add(new BigNumber(((a * pBytes * m4) + (b * qBytes * m1)) % (publicKey)));
                list.Add(new BigNumber(((a * pBytes * m3) + (b * qBytes * m2)) % (publicKey)));
                list.Add(new BigNumber(((a * pBytes * m4) + (b * qBytes * m2)) % (publicKey)));

                foreach (BigNumber result in list)
                {
                    byte[] rChecker;
                    if (result.dataLength < 3) {  }
                    else
                    {
                        rChecker = new[]
                            {result.getBytes()[result.dataLength - 2], result.getBytes()[result.dataLength - 1]};
                        byte[] kChecker = new[]
                        {
                            publicKey.getBytes()[0],
                            publicKey.getBytes()[1]
                        };
                        if (rChecker == kChecker)
                        {
                            byte[] tmp = new byte[result.dataLength - 2];

                            Array.Copy(result.getBytes(), tmp, result.dataLength - 2);

                            blockSolutions.Add(new BigNumber(tmp.ToList()));
                        }
                    }

                }
            }
            return blockSolutions;
            
        }

   

        public List<BigNumber> RabinEncyption(List<byte[]> bitBlockTab, BigNumber publicKey)
        {
            List<BigNumber> output =new List<BigNumber>();
            foreach (byte[] block in bitBlockTab)
            {
                BigNumber singleBlockNumber=new BigNumber(block.ToList());
                output.Add(singleBlockNumber.modPow(singleBlockNumber,publicKey));
            }
            return output;
        }

    }


    public enum ProcessType
    {
        Encryption,
        Decryption,
    }
}
