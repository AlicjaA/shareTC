﻿using System.Windows;
using OTPLibrary.Logic;

namespace PresentationLayer
{
	public partial class MainWindow : Window
	{
		EncryptionLib encryptionLib;
		NameGenerator nameGenerator;

		FileNamesPack fileNames;
		bool fileSelected;

		AvailableViews currentlySelectedView = AvailableViews.TextMode;
		FileEncryptionState fileEncryptionState = FileEncryptionState.Unknown;

		public MainWindow()
		{
			encryptionLib = new EncryptionLib();
			nameGenerator = new NameGenerator();

			fileNames = new FileNamesPack();
			fileSelected = false;

			InitializeComponent();
			UpdateViews();
		}
	}

	public enum AvailableViews
	{
		TextMode,
		FileMode,
	}

	public enum FileEncryptionState
	{
		Encrypted,
		NotEncrypted,
		Unknown,
	}
}
