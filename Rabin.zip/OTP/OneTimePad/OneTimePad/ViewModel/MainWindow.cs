﻿using System.IO;
using Microsoft.Win32;
using System.Windows;
using OTPLibrary.Logic;
using System.Windows.Media;

namespace PresentationLayer
{
	public partial class MainWindow : Window
	{
		private FileEncryptionState FileEncryptionState
		{
			get { return fileEncryptionState; }
			set { fileEncryptionState = value; UpdateFileButtons(); }
		}

		private void SetMessage(string message, bool error)
		{
			ErrorText.Text = message;
			ErrorText.Foreground = error ? Brushes.Red : Brushes.Black;
		}

		#region  Selecting mode
		private void TextModeButton_Click(object sender, RoutedEventArgs e)
		{
			currentlySelectedView = AvailableViews.TextMode;
			UpdateViews();
		}

		private void FileModeButton_Click(object sender, RoutedEventArgs e)
		{
			currentlySelectedView = AvailableViews.FileMode;
			UpdateViews();
		}
		#endregion

		#region Selecting file
		private void SelectFileButton_Click(object sender, RoutedEventArgs e)
		{
			OpenFileDialog openFileDialog = new OpenFileDialog();

			if (openFileDialog.ShowDialog() == true) // If user has selected file
			{
				fileNames = nameGenerator.GenerateFileNames(openFileDialog.FileName);
				fileSelected = true;
				FileEncryptionState = File.Exists(fileNames.keyName) ? FileEncryptionState.Encrypted : FileEncryptionState.NotEncrypted;
			}
			else
			{
				FileEncryptionState = FileEncryptionState.Unknown;
			}
		}
		#endregion

		#region Encryption/Decryption calls
		private void EncryptButton_Click(object sender, RoutedEventArgs e)
		{
			switch (currentlySelectedView)
			{
				case AvailableViews.TextMode:
					{
						if (InputTextField.Text.Length != 0)
						{
							// Encrypt text
							fileNames = nameGenerator.GetOnlyKeyName();
							OutputTextField.Text = encryptionLib.ProcessText(InputTextField.Text, fileNames.keyName, ProcessType.Encryption);

							SetMessage("Text has been encrypted", false);
						}
						else
						{
							SetMessage("Text field is empty", true);
						}
						fileEncryptionState = FileEncryptionState.Unknown;
						break;
					}
				case AvailableViews.FileMode:
					{
						if (fileSelected)
						{
							encryptionLib.ProcessFile
								(
								fileNames.inputName,
								fileNames.keyName,
								fileNames.outputName,
								ProcessType.Encryption 
								);

							SetMessage("File has been encrypted.", false);
						}
						FileEncryptionState = FileEncryptionState.Unknown;
						break;
					}
			}

			fileSelected = false;
		}

		private void DecryptButton_Click(object sender, RoutedEventArgs e)
		{
			switch (currentlySelectedView)
			{
				case AvailableViews.TextMode:
					{
						if (InputTextField.Text.Length != 0)
						{
							fileNames = nameGenerator.GetOnlyKeyName();

							if (File.Exists(fileNames.keyName))
							{
								// Decrypt Text
								OutputTextField.Text = encryptionLib.ProcessText(InputTextField.Text, fileNames.keyName, ProcessType.Decryption);

								if (InputTextField.Text == OutputTextField.Text)
								{
									SetMessage("Detected key doesn't match the provided text", true);
								}
								else
								{
									SetMessage("Text has been decrypted", false);
								}
							}
							else
							{
								SetMessage("There is no key file for this text", true);
							}
						}
						else
						{
							SetMessage("Text field is empty", true);
						}
						fileEncryptionState = FileEncryptionState.Unknown;
						break;
					}
				case AvailableViews.FileMode:
					{
						if (fileSelected)
						{
							encryptionLib.ProcessFile
								(
								fileNames.inputName,
								fileNames.keyName,
								fileNames.outputName,
								ProcessType.Decryption
								);

							SetMessage("File has been decrypted.", false);
						}
						FileEncryptionState = FileEncryptionState.Unknown;
						break;
					}
			}

			fileSelected = false;
			
		}
		#endregion

		#region Changing views
		private void UpdateViews()
		{
			fileSelected = false;
			FileEncryptionState = FileEncryptionState.Unknown;
			SetMessage("", false);

			switch (currentlySelectedView)
			{
				case AvailableViews.TextMode:
				{
					InputTextField.Text = "";
					OutputTextField.Text = "";
					InputInfo.Visibility = Visibility.Visible;
					InputTextField.Visibility = Visibility.Visible;
					OutputInfo.Visibility = Visibility.Visible;
					OutputTextField.Visibility = Visibility.Visible;

					SelectFileButton.Visibility = Visibility.Collapsed;
					EncryptButton.Visibility = Visibility.Visible;
					DecryptButton.Visibility = Visibility.Visible;
					break;
				}
				case AvailableViews.FileMode:
				{
					InputInfo.Visibility = Visibility.Collapsed;
					InputTextField.Visibility = Visibility.Collapsed;
					OutputInfo.Visibility = Visibility.Collapsed;
					OutputTextField.Visibility = Visibility.Collapsed;

					SelectFileButton.Visibility = Visibility.Visible;
					EncryptButton.Visibility = Visibility.Collapsed;
					DecryptButton.Visibility = Visibility.Collapsed;
					break;
				}	
			}
		}

		private void UpdateFileButtons()
		{
			switch (fileEncryptionState)
			{
				case FileEncryptionState.Encrypted:
				{
					EncryptButton.Visibility = Visibility.Collapsed;
					DecryptButton.Visibility = Visibility.Visible;
					break;
				}
				case FileEncryptionState.NotEncrypted:
				{
					EncryptButton.Visibility = Visibility.Visible;
					DecryptButton.Visibility = Visibility.Collapsed;
					break;
				}
				case FileEncryptionState.Unknown:
				{
					EncryptButton.Visibility = Visibility.Collapsed;
					DecryptButton.Visibility = Visibility.Collapsed;
					break;
				}
			}
		}
		#endregion
	}
}
