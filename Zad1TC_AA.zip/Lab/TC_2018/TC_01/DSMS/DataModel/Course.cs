﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;

namespace DataModel
{
    [DataContract()]
    [Serializable]
    public class Course
    {
        private int _id;
        private String _name;
        private int _courseTypeId;
        private List<DayOfWeek> _courseDays;
        private String _startHour;
        private String _endHour;
        private DateTimeOffset _dateStart;
        private DateTimeOffset _dateEnd;
        private DateTimeOffset _subscriptionStartDate;
        private int _maxMembers;
        private int _minMembers = 1;


        [DataMember()]
        public int Id { get => _id; set => _id = value; }
        [DataMember()]
        public string Name { get => _name; set => _name = value; }
        public int CourseTypeId { get => _courseTypeId; set => _courseTypeId = value; }
        [DataMember()]
        public List<DayOfWeek> CourseDays { get => _courseDays; set => _courseDays = value; }
        [DataMember()]
        public string StartHour { get => _startHour; set => _startHour = value; }
        [DataMember()]
        public string EndHour { get => _endHour; set => _endHour = value; }
        [DataMember()]
        public DateTimeOffset DateStart { get => _dateStart; set => _dateStart = value; }
        [DataMember()]
        public DateTimeOffset DateEnd { get => _dateEnd; set => _dateEnd = value; }
        [DataMember()]
        public DateTimeOffset SubscriptionStartDate { get => _subscriptionStartDate; set => _subscriptionStartDate = value; }
        [DataMember()]
        public int MaxMembers { get => _maxMembers; set => _maxMembers = value; }
        [DataMember()]
        public int MinMembers { get => _minMembers; set => _minMembers = value; }

        public string ToString(int whichData)
        {
            string data;
            switch (whichData)
            {
                case 0:
                    data = Name;
                    break;
                case 1:
                    data = Name + " " + CourseDays;
                    break;
                default:
                    data = base.ToString();
                    break;
            }

            return data;
        }
    }
}
