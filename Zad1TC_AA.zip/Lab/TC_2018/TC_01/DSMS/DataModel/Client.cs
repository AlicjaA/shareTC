﻿using System;
using System.Runtime.Serialization;

namespace DataModel
{
    [DataContract()]
    [Serializable]
    public class Client
    {
        private int _id;
        private String _forename;
        private String _secondForename;
        private String _surname;
        private String _email;
        private String _phone;
        private int _age;
        private int _parentId;

        public Client()
        {
        }

        public Client(int id, string forename, string secondForename, string surname, string email, string phone, int age)
        {
            _id = id;
            _forename = forename;
            _secondForename = secondForename;
            _surname = surname;
            _email = email;
            _phone = phone;
            _age = age;
        }

        [DataMember()]
        public int Id { get=>_id; set=>_id=value; }
        [DataMember()]
        public string Forename { get => _forename; set => _forename = value; }
        [DataMember()]
        public string SecondForename { get => _secondForename; set => _secondForename = value; }
        [DataMember()]
        public string Surname { get => _surname; set => _surname = value; }
        [DataMember()]
        public string Email { get => _email; set => _email = value; }
        [DataMember()]
        public string Phone { get => _phone; set => _phone = value; }
        [DataMember()]
        public int Age { get => _age; set => _age = value; }
        [DataMember()]
        public int ParentId { get => _parentId; set => _parentId = value; }

        public string ToString(int whichData)
        {
            string data;
            switch (whichData)
            {
                case 0:
                    data = Forename +" "+Surname;
                    break;
                case 1:
                    data = Forename + " " + Surname+ " "+Phone;
                    break;
                default:
                    data = base.ToString();
                    break;
            }

            return data;
        }
    }
}
