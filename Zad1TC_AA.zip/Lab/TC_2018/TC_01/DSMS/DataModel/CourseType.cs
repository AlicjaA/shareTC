﻿using System;
using System.Runtime.Serialization;

namespace DataModel
{
    [DataContract()]
    [Serializable]
    public class CourseType
    {
        private int _id;
        private String _name;

        [DataMember()]
        public int Id { get => _id; set => _id = value; }
        [DataMember()]
        public string Name { get => _name; set => _name = value; }
    }
}
