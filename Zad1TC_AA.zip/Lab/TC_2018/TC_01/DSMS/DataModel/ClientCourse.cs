﻿using System;
using System.Runtime.Serialization;

namespace DataModel
{
    [DataContract()]
    [Serializable]
    public class ClientCourse
    {
        private Client _client;
        private Course _course;

        public ClientCourse()
        {
        }

       

        [DataMember()]
        public Client Client { get => _client; set => _client = value; }
        [DataMember()]
        public Course Course { get => _course; set => _course = value; }

        public override string ToString()
        {
            string data = _course.ToString(0)  + " "+ _client.ToString(0);
            return data;
        }
    }
}
