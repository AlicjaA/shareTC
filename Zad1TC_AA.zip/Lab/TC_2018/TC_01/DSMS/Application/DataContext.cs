﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.Runtime.Serialization;
using DataModel;

namespace Application
{
    [DataContract()]
    [Serializable]
    class DataContext
    {
        [DataMember()] public List<Client> ClientList;

        [DataMember()] public Dictionary<int, CourseType> CourseTypeDictionary;

        [DataMember()] public ObservableCollection<ClientCourse> ClientCourseCollection;

        [DataMember()] public List<Course> CourseList;

        public DataContext()
        {
            ClientList = new List<Client>();
            CourseTypeDictionary = new Dictionary<int, CourseType>();
            ClientCourseCollection = new ObservableCollection<ClientCourse>();
            CourseList = new List<Course>();

            void ClientCourseCollection_CollectionChanged(object sender, NotifyCollectionChangedEventArgs e)
            {
                if (e.NewItems != null)
                {
                    Console.WriteLine("Zapisano na zajęcia następujących Klientów: ");
                    foreach (var item in e.NewItems)
                    {

                        Console.WriteLine(item.ToString());
                    }
                }

                if (e.OldItems != null)
                {
                    Console.WriteLine("Wypisano z zajęć następujących Klientów: ");
                    foreach (var item in e.OldItems)
                    {
                        Console.WriteLine(item.ToString());
                    }
                }
            }

        }
    }
}
